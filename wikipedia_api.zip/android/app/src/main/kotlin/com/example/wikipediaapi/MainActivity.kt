package com.example.wikipediaapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
